/**
 * EgenSpringApplicationTests
 * Application Test class
 * @author Sri Harsha Vardhan Reddi
 */
package com.egen;

import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import com.egen.api.EgenSpringApplication;
import com.egen.model.Alerts;
import com.egen.model.Metrics;
import com.egen.repository.AlertsRepository;
import com.egen.repository.MetricsRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = EgenSpringApplication.class)
@WebAppConfiguration
public class EgenSpringApplicationTests {
	
	@Autowired
	MetricsRepository metrics;
	@Autowired
	AlertsRepository alerts;

	/**
	 * Test for create metrics method
	 */
	@Test
	public void createMetrics() {
		Metrics metric = new Metrics(160, new Date());
		metric = metrics.createMetrics(metric);
		Assert.assertNotNull("Failure - Expected not null", metric);
	}
	
	/**
	 * Test to find all metrics method
	 */
	@Test
	public void findAllMetrics(){
		List<Metrics> stats = metrics.readAllMetrics();
		Assert.assertNotNull("Failure - Expected not null", stats);
	}
	
	/**
	 * Test to find metrics by range
	 */
	@Test
	public void findMetricsByRange(){
		List<Metrics> stats = metrics.readMetricsByRange("1463604099", "1463604115");
		Assert.assertEquals(0, stats.size());
	}
	
	/**
	 * Test to create alerts 
	 */
	@Test
	public void createAlerts(){
		Alerts alert = new Alerts("Testing Alerts", new Date());
		alert = alerts.createAlerts(alert);
		Assert.assertNotNull("Failure - Expected not null", alert);
	}
	
	/**
	 * Test to find all alerts method
	 */
	@Test
	public void findAllAlert(){
		List<Alerts> stats = alerts.readAllAlerts();
		Assert.assertNotNull("Failure - Expected not null", stats);
	}
	
	/**
	 * Test to find alerts by range
	 */
	@Test
	public void findAlertsByRange(){
		List<Alerts> stats = alerts.readAlertsByRange("1463604099", "1463604115");
		Assert.assertEquals(0, stats.size());
	}

}
