/**
 * EgenSpringApplication
 * Spring boot application class
 * @author Sri Harsha Vardhan Reddi
 */
package com.egen.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.egen" })
public class EgenSpringApplication {

	/**
	 * Main method to run the application
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(EgenSpringApplication.class, args);
	}
}
