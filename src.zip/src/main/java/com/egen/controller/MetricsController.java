/**
 * MetricsController Class
 * Contains all the Metrics web services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.egen.model.Metrics;
import com.egen.repository.MetricsRepository;

@RestController
@RequestMapping(value = "/metrics")
public final class MetricsController {
	
	/**
	 * Private members
	 */
	@Autowired
	private MetricsRepository metricsRepository;
	
	/**
	 * Micro-service to insert the metrics
	 * @param metric
	 * @param builder
	 * @return
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<Void> create(@RequestBody Metrics metric, UriComponentsBuilder builder){
		
		metricsRepository.createMetrics(metric);
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	/**
	 * Micro-service to get all the metrics data.
	 * @param builder
	 * @return
	 */
	@RequestMapping(value = "/readall", method = RequestMethod.GET)
	public List<Metrics> readAllMetrics(@RequestBody Metrics metric, UriComponentsBuilder builder){
		
		List<Metrics> response = metricsRepository.readAllMetrics();
		return response;
	}
	
	/**
	 * Micro-service to get the metrics data by range
	 * @param metric
	 * @param builder
	 * @return
	 */
	@RequestMapping(value = "/read/{min}/{max}", method = RequestMethod.GET)
	public List<Metrics> readMetricsByRange(@PathVariable(value = "min") String min, 
			@PathVariable(value = "max") String max){
		
		List<Metrics> response = metricsRepository.readMetricsByRange(min, max);
		return response;
	}
}
