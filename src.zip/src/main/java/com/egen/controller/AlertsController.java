/**
 * AlertsController Class
 * Contains all the Alerts web services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import com.egen.model.Alerts;
import com.egen.repository.AlertsRepository;

@RestController
@RequestMapping(value = "/alerts")
public final class AlertsController {
	
	/**
	 * Private members
	 */
	@Autowired
	private AlertsRepository alertsRepository;
	
	/**
	 * Micro-service to get all the alerts data.
	 * @param builder
	 * @return
	 */
	@RequestMapping(value = "/readall", method = RequestMethod.GET)
	public List<Alerts> readAllAlerts(UriComponentsBuilder builder){
		
		List<Alerts> response = alertsRepository.readAllAlerts();
		return response;
	}
	
	/**
	 * Micro-service to get the alerts data by range
	 * @param metric
	 * @param builder
	 * @return
	 */
	@RequestMapping(value = "/read/{min}/{max}", method = RequestMethod.GET)
	public List<Alerts> readAlertsByRange(@PathVariable(value = "min") String min, 
			@PathVariable(value = "max") String max){
		
		List<Alerts> response = alertsRepository.readAlertsByRange(min, max);
		return response;
	}
}
