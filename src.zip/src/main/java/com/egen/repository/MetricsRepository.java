/**
 * MetricsRepository interface
 * Contains all the Metrics services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.repository;

import java.util.List;
import com.egen.model.Metrics;

public interface MetricsRepository {

	/**
	 * Method to insert the metric data
	 * @param metric
	 * @return
	 */
	public Metrics createMetrics(Metrics metric);

	/**
	 * Method to get all the metric data
	 * @return
	 */
	public List<Metrics> readAllMetrics();
	
	/**
	 * Method to get the metric data within the given range
	 * @param min
	 * @param max
	 * @return
	 */
	public List<Metrics> readMetricsByRange(String min, String max);
}
