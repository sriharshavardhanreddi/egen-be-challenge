/**
 * AlertsRepositoryImpl interface
 * Contains implementation of all the alert services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.repository;

import java.util.Date;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import com.egen.model.Alerts;

@Repository
public class AlertsRepositoryImpl implements AlertsRepository{
	
	/**
	 * Private members
	 */
	ApplicationContext context = new GenericXmlApplicationContext("spring-configuration.xml");
	MongoOperations mongoOperation = (MongoOperations)context.getBean("mongoTemplate");

	/**
	 * Method used to create alerts
	 * @return
	 */
	@Override
	public Alerts createAlerts(Alerts alert){
		mongoOperation.save(alert);
		return alert;
	}
	/**
	 * Method to get all the metric data
	 * @return
	 */
	@Override
	public List<Alerts> readAllAlerts() {
		return mongoOperation.findAll(Alerts.class);
	}

	/**
	 * Method to get the metric data within the given range
	 * @param min
	 * @param max
	 * @return
	 */
	@Override
	public List<Alerts> readAlertsByRange(String min, String max) {
		Date minDate = new Date(Long.parseLong(min));
		Date maxDate = new Date(Long.parseLong(max));
		Query query = new Query().addCriteria(Criteria.where("timeStamp").gt(minDate).lte(maxDate));
        return mongoOperation.find(query, Alerts.class);
	}

}
