/**
 * MetricsRepositoryImpl interface
 * Contains implementation of all the Metrics services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.repository;

import java.util.Date;
import java.util.List;

import org.easyrules.api.RulesEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import com.egen.model.Metrics;
import com.egen.rules.OverWeightRule;
import com.egen.rules.UnderWeightRule;

@Repository
public class MetricsRepositoryImpl implements MetricsRepository{
	
	/**
	 * Private members
	 */
	@Autowired 
	AlertsRepository alerts;
	private ApplicationContext context = new GenericXmlApplicationContext("spring-configuration.xml");
	private MongoOperations mongoOperation = (MongoOperations)context.getBean("mongoTemplate");

	RulesEngine rulesEngine = (RulesEngine)context.getBean("rulesEngine");
	OverWeightRule overWeightRule = (OverWeightRule)context.getBean("overWeightRule");
	UnderWeightRule underWeightRule = (UnderWeightRule)context.getBean("underWeightRule");
	
	/**
	 * Method to insert the metric data
	 * @param metric
	 * @return
	 */
	@Override
	public Metrics createMetrics(Metrics metric) {
		overWeightRule.setWeight(metric.getValue());
		overWeightRule.setAlertsRepository(alerts);
		underWeightRule.setWeight(metric.getValue());
		underWeightRule.setAlertsRepository(alerts);
		rulesEngine.fireRules();
		mongoOperation.save(metric);
		return metric;
	}

	/**
	 * Method to get all the metric data
	 * @return
	 */
	@Override
	public List<Metrics> readAllMetrics() {
		return mongoOperation.findAll(Metrics.class);
	}

	/**
	 * Method to get the metric data within the given range
	 * @param min
	 * @param max
	 * @return
	 */
	@Override
	public List<Metrics> readMetricsByRange(String min, String max) {
		Date minDate = new Date(Long.parseLong(min));
		Date maxDate = new Date(Long.parseLong(max));
		
		
		Query query = new Query().addCriteria(Criteria.where("timeStamp").gt(minDate).lte(maxDate));
        return mongoOperation.find(query, Metrics.class);
		
		
//      List<Metrics> result= new ArrayList<Metrics>();
//		BasicDBObject query = new BasicDBObject();
//		query.put("timeStamp", new BasicDBObject("$gte", minDate));
//		query.append("timeStamp", new BasicDBObject("$lte", maxDate));
//		DBCollection metrics = mongoOperation.getCollection("metrics");
//		DBCursor cursor = metrics.find(query).sort(new BasicDBObject("timeStamp", -1));
//		if(cursor.length() > 0){
//		while(cursor.hasNext()){
//			DBObject object = cursor.next();
//			Metrics metric = new Metrics();
//			metric.setId(object.get("id").toString());
//			metric.setValue((Integer)object.get("value"));
//			metric.setTimeStamp((Date)object.get("timeStamp"));
//			result.add(metric);
//		}
//		} else{
//			System.out.println("*********Empty Get***********");
//		}
//		return result;
	}

}
