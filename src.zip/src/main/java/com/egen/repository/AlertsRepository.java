/**
 * AlertsRepository interface
 * Contains all the Alert services.
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.repository;

import java.util.List;
import com.egen.model.Alerts;

public interface AlertsRepository {
	
	/**
	 * Method to insert the alert data
	 * @param alert
	 * @return
	 */
	public Alerts createAlerts(Alerts alert);

	/**
	 * Method to get all the alert data
	 * @return
	 */
	public List<Alerts> readAllAlerts();
	
	/**
	 * Method to get the alert data within the given range
	 * @param min
	 * @param max
	 * @return
	 */
	public List<Alerts> readAlertsByRange(String min, String max);
}
