/**
 * Alerts Class
 * Model class of metrics class
 * Author : Sri Harsha Vardhan Reddi
 */
package com.egen.model;

import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Document(collection="alerts")
public class Alerts {
	
	/**
	 * Private members  
	 */
	@Id
    private String id;
    
    private String alert;
    
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private Date timeStamp;
    
    /**
     * Default Constructor
     */
    public Alerts(){
    	this.alert = null;
    	this.timeStamp = new Date();
    }
    
    /**
     * Parameterized Constructor
     * @param alert
     * @param timeStamp
     */
    public Alerts(String alert, Date timeStamp){
        this.alert = alert;
        this.timeStamp = timeStamp;
    }
  
    /**
     * Method to get the string value of the Metrics object
     */
    @Override
    public String toString() {
        return String.format("[id = %s, alert = %s, timestamp = %s]", id, alert, timeStamp);
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

} 
