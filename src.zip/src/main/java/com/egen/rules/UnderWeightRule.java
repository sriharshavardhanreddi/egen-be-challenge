/**
 * UnderWeightRule
 * Spring Rule class
 * @author Sri Harsha Vardhan Reddi
 */
package com.egen.rules;

import java.util.Date;
import org.easyrules.annotation.Action;
import org.easyrules.annotation.Condition;
import org.easyrules.annotation.Rule;
import com.egen.model.Alerts;
import com.egen.repository.AlertsRepository;

@Rule(name = "Under Weight Rule")
public class UnderWeightRule {
	
	/**
	 * Private members;
	 */
	private AlertsRepository alertsRepository;
	private static Integer baseWeight = 160; //Integer.parseInt(System.getProperty("base.value"));
	private Integer weight;
	
	/**
	 * The condition for the rule
	 * @param weight
	 * @return
	 */
	@Condition
	public boolean when(){
		boolean result = false;
		if(weight < (baseWeight - (baseWeight / 10))){
			result = true;
		}
		return result;
	}
	
	/**
	 * The action to be taken
	 */
	@Action
	public void then(){
		Alerts alert = new Alerts();
		alert.setAlert("Detected Under Weight");
		alert.setTimeStamp(new Date());
		alertsRepository.createAlerts(alert);
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public AlertsRepository getAlertsRepository() {
		return alertsRepository;
	}

	public void setAlertsRepository(AlertsRepository alertsRepository) {
		this.alertsRepository = alertsRepository;
	}

	public static Integer getBaseWeight() {
		return baseWeight;
	}

	public static void setBaseWeight(Integer baseWeight) {
		UnderWeightRule.baseWeight = baseWeight;
	}
}
